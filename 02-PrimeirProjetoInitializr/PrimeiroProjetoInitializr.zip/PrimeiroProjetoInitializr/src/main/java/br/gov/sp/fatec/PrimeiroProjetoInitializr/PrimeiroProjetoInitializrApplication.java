package br.gov.sp.fatec.PrimeiroProjetoInitializr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimeiroProjetoInitializrApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimeiroProjetoInitializrApplication.class, args);
	}

}
