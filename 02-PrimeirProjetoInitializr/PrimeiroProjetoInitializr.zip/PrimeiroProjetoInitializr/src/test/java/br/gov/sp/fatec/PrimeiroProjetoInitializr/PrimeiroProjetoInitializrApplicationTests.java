package br.gov.sp.fatec.PrimeiroProjetoInitializr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroProjetoInitializrApplicationTests {

	@Test
	void contextLoads() {
	}

}
